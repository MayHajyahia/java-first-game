import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
//My first experience developing a game with Frames (:

public class GamePanel extends JPanel implements ActionListener {

    // Constants for the game dimensions and settings
    static final int SCREEN_WIDTH = 1000;
    static final int SCREEN_HEIGHT = 750;
    static final int UNIT_SIZE = 40;
    static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
    static final int DELAY = 175;

    // Arrays to hold the x and y coordinates of the snake's body parts
    final int x[] = new int[GAME_UNITS];
    final int y[] = new int[GAME_UNITS];

    // Game variables
    int bodyParts = 10; // number of snake body parts
    int applesEaten; // score of eaten apples
    int appleX; // X coordinate of the apple
    int appleY; // Y coordinate of the apple
    char direction = 'R'; // initial value direction of the snake (Right)
    boolean running = false; // game running state
    boolean showInstructions = true; // instruction screen visibility

    Timer timer; // timer for controlling the game loop
    Random random; // random object for generating apple positions

    // fonts for different text displays
    Font instructionFont = new Font("Serif", Font.BOLD, 24);
    Font scoreFont = new Font("Arial", Font.BOLD, 40);
    Font gameOverFont = new Font("Ink Free", Font.BOLD, 75);

    // Constructor for the GamePanel
    GamePanel() {
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());
    }

    // Method to start the game
    public void start() {
        newApple(); // Generate a new apple
        running = true; // Set the game state to running
        timer = new Timer(DELAY, this); // Initialize the timer with delay and action listener
        timer.start(); // Start the timer
    }

    // overridden paint method to draw the game
    public void paint(Graphics g) {
        super.paintComponent(g);
        draw(g); // call the draw method to render the game
    }

    // method to handle the drawing logic
    public void draw(Graphics g) {
        if (showInstructions) {
            drawInstructions(g); 
        } else if (running) {
            // draw the apple
            g.setColor(Color.yellow);
            g.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);

            // draw the snake
            for (int i = 0; i < bodyParts; i++) 
                if (i == 0) {
                    g.setColor(Color.green); //snake head
                    g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
                else {
                    g.setColor(new Color(45, 180, 0)); // snake boody
                    g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
            
            // Draw the score
            g.setColor(Color.red);
            g.setFont(scoreFont);
            FontMetrics metrics = getFontMetrics(g.getFont());
            g.drawString("Score: " + applesEaten, (SCREEN_WIDTH - metrics.stringWidth("Score: " + applesEaten)) / 2, g.getFont().getSize());
        } else 
            gameOver(g);
        
    }

    // method to draw the instructions on the screen
    public void drawInstructions(Graphics g) {
        String[] instructions = {
            "Welcome to the Snake Game!",
            "Instructions:",
            "1. Use arrow keys to move the snake.",
            "2. Eat apples to grow your snake.",
            "3. Don't hit the walls or your own tail.",
            "Press any key to start the game.",
            "  have fun :) "
        };

        g.setColor(Color.blue);
        g.setFont(instructionFont);
        FontMetrics m = getFontMetrics(g.getFont());

        int y = SCREEN_HEIGHT / 4;
        for (String line : instructions) {
            g.drawString(line, (SCREEN_WIDTH - m.stringWidth(line)) / 2, y); 
            y += 50; 
        }
    }

    public void newApple() {
        appleX = random.nextInt((int) (SCREEN_WIDTH / UNIT_SIZE)) * UNIT_SIZE;
        appleY = random.nextInt((int) (SCREEN_HEIGHT / UNIT_SIZE)) * UNIT_SIZE;
    }

    // method to move the snake
    public void move() {
        for (int j = bodyParts; j > 0; j--) {
            x[j] = x[j - 1];
            y[j] = y[j - 1];
        }

        // move the head of the snake in the current direction
        switch (direction) {
            case 'U':
                y[0] = y[0] - UNIT_SIZE;
                break;
            case 'D':
                y[0] = y[0] + UNIT_SIZE;
                break;
            case 'L':
                x[0] = x[0] - UNIT_SIZE;
                break;
            case 'R':
                x[0] = x[0] + UNIT_SIZE;
                break;
        }
    }

    // method to check if the snake has eaten an apple
    public void checkApple() {
        if ((x[0] == appleX) && (y[0] == appleY)) {
            bodyParts++; 
            applesEaten++; 
            newApple();
        }
    }

    // method to check for collisions
    public void checkCollisions() {
        for (int i = bodyParts; i > 0; i--) {
            if ((x[0] == x[i]) && (y[0] == y[i])) {
                running = false;
            }
        }
      
        if (x[0] < 0) {
            running = false;         }
        
        if (x[0] > SCREEN_WIDTH) {
            running = false; 
        }
        
        if (y[0] < 0) {
            running = false; 
        }
       
        if (y[0] > SCREEN_HEIGHT) {
            running = false;
        }

        if (!running) {
            timer.stop(); // stop the timer if the game ends
        }
    }

    // method to display the game over screen
    public void gameOver(Graphics g) {
      
        g.setColor(Color.red);
        g.setFont(scoreFont);
        FontMetrics metrics1 = getFontMetrics(g.getFont());
        g.drawString("Score: " + applesEaten, (SCREEN_WIDTH - metrics1.stringWidth("Score: " + applesEaten)) / 2, g.getFont().getSize());

        g.setColor(Color.red);
        g.setFont(gameOverFont);
        FontMetrics metrics2 = getFontMetrics(g.getFont());
        g.drawString("Game Over", (SCREEN_WIDTH - metrics2.stringWidth("Game Over")) / 2, SCREEN_HEIGHT / 2);
    }

    // overridden actionPerformed method to handle the game loop
    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            move(); 
            checkApple(); 
            checkCollisions();
        }
        repaint(); 
    }

    // inner class to handle key events
    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            if (showInstructions) {
                showInstructions = false; // hide instructions when any key is pressed
                start(); 
            } else {
                // change the direction based on the arrow key pressed
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        if (direction != 'R') {
                            direction = 'L';
                        }
                        break;
                    case KeyEvent.VK_RIGHT:
                        if (direction != 'L') {
                            direction = 'R';
                        }
                        break;
                    case KeyEvent.VK_UP:
                        if (direction != 'D') {
                            direction = 'U';
                        }
                        break;
                    case KeyEvent.VK_DOWN:
                        if (direction != 'U') {
                            direction = 'D';
                        }
                        break;
                }
            }
        }
    }
}
